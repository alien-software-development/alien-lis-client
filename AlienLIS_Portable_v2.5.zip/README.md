# Alien LIS Middleware Pro - Universal Hematology & Laboratory Information System

[![Platform](https://img.shields.io/badge/Platform-Windows%207%20%7C%208%20%7C%2010%20%7C%2011%20%7C%20Server-0078D7.svg)](https://microsoft.com)
[![Framework](https://img.shields.io/badge/.NET%20Framework-4.0%2B-512BD4.svg)](https://dotnet.microsoft.com)
[![Protocol](https://img.shields.io/badge/Protocols-HL7%20v2.x%20%7C%20ASTM%201381%2F1394-10b981.svg)](https://hl7.org)
[![Interfacing](https://img.shields.io/badge/Interface-TCP%2FIP%20MLLP%20%7C%20RS--232%20Serial-0ea5e9.svg)](https://aliensoftwaredevelopment.com)
[![Database](https://img.shields.io/badge/Database-Oracle%20%7C%20MSSQL%20%7C%20MySQL%20%7C%20SQLite-f59e0b.svg)](https://aliensoftwaredevelopment.com)
[![GitHub](https://img.shields.io/badge/GitHub-alien--software--development-181717.svg?logo=github)](https://github.com/alien-software-development)
[![License](https://img.shields.io/badge/License-Hardware--Locked%20Commercial%20%7C%207--Day%20Trial-8b5cf6.svg)](https://aliensoftwaredevelopment.com)

**Alien LIS Middleware Pro** is a high-performance, clinical-grade Laboratory Information System (LIS) middleware developed in C# for automated blood analyzers. It seamlessly captures raw telemetry from 3-part and 5-part automated hematology analyzers via **TCP/IP Ethernet (HL7 MLLP)** or **RS-232 Serial COM (ASTM / HL7)**, provides real-time intelligent clinical status evaluation, queries hospital billing/HIS software for patient demographics, and generates executive A4 laboratory reports.

---

## 🌟 Key Features in Version 2.5

### 1. Universal Hematology Analyzer Interfacing
* **TCP/IP Socket Server**: High-throughput asynchronous listener with standard MLLP framing (`<VT>...<FS><CR>`) and sub-50ms bidirectional `MSA|AA` acknowledgment.
* **Serial RS-232 COM Interfacing**: Direct serial communication supporting COM1 through COM32, configurable baud rates (9600 to 115200), parity, stop bits, and hardware flow control.
* **Universal Compatibility**: Works out of the box with any standard automated hematology analyzer (Mindray, Sysmex, Dymind, KT-series, Rayto, URIT, Dirui, Genrui, Biossays, Zybio, Abbott Cell-Dyn, Beckman Coulter, etc.).
* **⚡ Live Communication Diagnostics**: Instant one-click diagnostic test button to verify socket availability or execute serial hardware handshakes.

### 2. Multi-Tier Demographic Reference Ranges & Status Evaluation
* **Demographic-Aware Flagging**: Evaluates test status against patient gender (`Male`, `Female`) and age bracket (`Adult`, `Child`, `Infant`) rather than a flat combined range.
* **South Asian Age Notation Parser**: Seamlessly interprets age notations such as `36y m d`, `35y 0m 0d`, `2y 3m d`, `0y 6m 0d`, `15d`, and standard years (`35 Y`, `12y`).
* **HGB Clinical Range Alignment**: Evaluates Hemoglobin against demographic tiers:
  * **Adult Male**: Evaluated against male clinical reference (e.g. `12.0 - 16.0` or `13.0 - 17.5 g/dL`).
  * **Adult Female**: Evaluated against female reference (e.g. `10.5 - 15.0` or `11.5 - 15.5 g/dL`).
  * **Child / Infant**: Evaluated against pediatric reference standards (e.g. `13.0 - 19.0 g/dL`).
* **WBC Clinical Range Alignment**:
  * **Adults**: Evaluated against adult intervals (e.g. `4.0 - 11.0 × 10⁹/L` or `4,000 - 11,000 /cumm`).
  * **Children**: Evaluated against child intervals (e.g. `5.0 - 15.0 × 10⁹/L`).
  * **Infants**: Evaluated against infant intervals (e.g. `6.0 - 18.0 × 10⁹/L`).
* **Automatic Unit & Number Scaling**: Automatically scales values between `10⁹/L` and `/cumm` (e.g. `3.5` vs `3500`, `12.5` vs `12500`).

### 3. Dual Report Modes (CBC Clinical Report & Dedicated Hemoglobin Report)
* **Dedicated Hemoglobin (Hb / HGB) Report**:
  * One-click print for rapid pre-operative, antenatal, or standalone hemoglobin screening.
  * Configurable report title (e.g. *"BLOOD HEMOGLOBIN (Hb / HGB) EXAMINATION REPORT"*).
  * Adjustable vertical spacing (`HgbPatientResultGap`) between patient demographics card and results table.
  * Direct auto-print support without print dialog for high-volume lab workflows.
* **Complete Blood Count (CBC) Clinical Report**:
  * Full 23+ parameter table with differential leukocyte counts (Neutrophils, Lymphocytes, Monocytes, Eosinophils, Basophils, LIC, ALY, TCE).
  * High-resolution WBC, RBC, and PLT distribution histograms with mathematical curve rendering and discriminator thresholds.
  * Visual Range Indicator bars with color-coded status markers (Orange for Low, Green for Normal, Red for High).
  * Clinical remarks, morphology impressions, and methodology notes.

### 4. Two-Way Hospital HIS / LIS Database Synchronization
* **Automated Demographic Lookup**: Queries your hospital billing, OPD, or HMIS database by Barcode / Sample ID to automatically populate patient name, age, gender, bed/ward number, and referring doctor.
* **Two-Way Results Sync**: Automatically writes validated laboratory results back into the external hospital database upon analysis.
* **Supported Databases**: Native direct support for **Oracle Database**, **Microsoft SQL Server**, **MySQL / MariaDB**, **SQLite**, and **Microsoft Access**.
* **⚡ Auto-Create Target Table Schema**: One-click schema generator that automatically creates the destination clinical results table or adds missing columns non-destructively.

### 5. Professional Typography & Layout Controls
* **South Asian Number Formatting**: Platelet counts and WBC counts automatically display with standard clinical thousands grouping (e.g. `4,25,000 /cumm`).
* **Full Signature Block Configuration**: Supports up to 3 medical signature blocks (Medical Technologist, Biochemist, Consultant Pathologist) with titles, doctor names, and degrees.
* **Developer Branding Controls**: Configurable vertical edge branding with faint watermark styling and safety margins preventing physical paper cut-off.

### 6. Zero-Install 100% Portable Architecture
* **Pure Managed C# Drivers**: Bundled pure managed drivers for Oracle, MySQL, and SQLite. No Oracle Instant Client, ODBC setup, or client software installation required.
* **Drop-in Deployment**: Runs directly from any USB flash drive or folder on Windows 7 SP1, 8, 10, 11, and Windows Server (32-bit and 64-bit).

### 7. Offline Hardware-Locked Licensing
* **🎁 7-Day Unrestricted Free Trial**: Instant one-click trial activation with all features unlocked.
* **Lifetime Hardware-Locked Activation**: Machine ID cryptographic binding for secure commercial licensing.
* **Standalone Generator Apps**: Includes `LicenseGenerator.exe` (GUI) and `KeyGen.exe` (Console) for authorized distributors and lab administrators.

---

## 🏗️ System Architecture Workflow

```mermaid
flowchart LR
    subgraph Analyzer["Automated Hematology Analyzer"]
        Machine["Blood Analyzer\n(Mindray, Sysmex, KT-44, etc.)"]
    end

    subgraph Middleware["Alien LIS Middleware Pro"]
        Listener["Socket Listener (TCP 5100)\nor Serial COM Port"]
        Parser["HL7 / ASTM Telemetry Parser\n& Unit Normalizer"]
        Engine["Intelligent Status Engine\n(Gender & Age Bounds)"]
        LocalDB[("Local Embedded DB\n(SQLite)")]
    end

    subgraph Hospital["Hospital HIS / LIS Infrastructure"]
        HIS[("Hospital Billing / HIS\n(Oracle / MSSQL / MySQL)")]
    end

    subgraph Output["Clinical Output"]
        Print1["A4 CBC Clinical Report\n(Histograms & Differentials)"]
        Print2["Dedicated HGB Report\n(Single-Parameter Screening)"]
    end

    Machine -- "HL7 MLLP or ASTM" --> Listener
    Listener --> Parser
    Parser --> Engine
    Engine <--> LocalDB
    Engine <--> |"Lookup Demographics & Sync Results"| HIS
    Engine --> Print1
    Engine --> Print2
```

---

## 🚀 Quick Start Guide

### Step 1: Connect Your Analyzer
* **Ethernet Cable (TCP/IP)**: Connect a standard RJ45 network cable between the analyzer and your PC or network switch.
* **Serial Cable (RS-232)**: Connect a DB9 serial cable or USB-to-RS232 adapter from the analyzer to your computer.

### Step 2: Launch Alien LIS Middleware
1. Open the portable folder and run `AlienLISMiddleware.exe` (or `Run_AlienLIS.bat`).
2. The top status bar will display `● LISTENING (0.0.0.0:5100)`.
3. To configure Serial COM port or change TCP port:
   - Navigate to the **Database & Machine Setup** tab (Default Admin PIN: `1234`).
   - Select **Serial COM Port** or **TCP/IP Ethernet**.
   - Click **⚡ Test Connection** to verify hardware readiness.

### Step 3: Run Blood Tests
1. Run blood samples on the analyzer.
2. The middleware automatically captures the telemetry, acknowledges the analyzer within milliseconds, and lists the sample in the **Live Sample Queue**.
3. Select any sample to view results, edit demographics, or click **🖨️ Print Clinical Report** (or **🩸 Print HGB Report**).

---

## ⚙️ Analyzer Configuration Guide

Configure your analyzer's communication settings as follows:

| Setting Parameter | TCP/IP (Ethernet) Recommended | Serial RS-232 |
|:---|:---|:---|
| **Protocol** | HL7 (v2.3.1 / v2.4 / v2.5) | ASTM 1381/1394 or HL7 |
| **Transmission Mode** | Auto-Send / Real-Time | Auto-Send / Real-Time |
| **LIS Server IP** | PC Local IP (e.g. `192.168.1.50`) | N/A |
| **LIS Server Port** | `5100` (configurable) | N/A |
| **Baud Rate** | N/A | `19200` or `115200` |
| **Data Bits / Parity / Stop Bits** | N/A | `8` / `None` / `1` |
| **Handshake / Flow Control** | N/A | `None` |

---

## 🗄️ External HIS / Demographic Database Setup

To automatically fetch patient demographics (Patient Name, Age, Gender, Bed No, Referring Doctor):

1. Go to **Database & Machine Setup** (PIN: `1234`).
2. Under **External Patient Demographics Setup**, choose your database engine:
   * **Oracle Database** (Pure managed - no Instant Client required)
   * **Microsoft SQL Server**
   * **MySQL / MariaDB**
   * **SQLite**
3. Configure your server Host, Port, Database, User ID, and Password.
4. Set table column mappings:
   * **Patient Table**: e.g. `LAB_BOOKING` or `PATIENTS`
   * **Sample ID / Barcode Column**: `SAMPLE_ID` or `BARCODE`
   * **Patient Name Column**: `PATIENT_NAME`
   * **Age Column**: `AGE`
   * **Gender Column**: `GENDER` or `SEX`
   * **Bed No Column**: `BED_NO` or `CABIN_NO`
   * **Doctor Name Column**: `REF_DOCTOR`
5. Click **⚡ Test Patient Lookup** with any test sample ID to confirm live integration.

---

## 📋 Auto-Created Results Database Schema

Clicking **"⚡ Auto-Create Target Table"** creates or upgrades the destination table in your external hospital database:

| Column Name | Data Type | Description |
|:---|:---|:---|
| `LAB_NO` | VARCHAR(50) PRIMARY KEY | Barcode or Sample Identifier |
| `TEST_DATE` | DATETIME / DATE | Timestamp of Blood Analysis |
| `PATIENT_NAME` | VARCHAR(100) | Patient Full Name |
| `AGE` | VARCHAR(20) | Patient Age (e.g. `35y 0m 0d`, `28Y`) |
| `GENDER` | VARCHAR(10) | Patient Gender (`Male`, `Female`, `Other`) |
| `BED_NO` | VARCHAR(50) | Inpatient Bed / Cabin / Ward Number |
| `REF_BY` | VARCHAR(100) | Referring Doctor Name |
| `WBC` | DECIMAL(10,2) | Total White Blood Cells (10⁹/L) |
| `RBC` | DECIMAL(10,2) | Red Blood Cells (10¹²/L) |
| `HGB` | DECIMAL(10,2) | Hemoglobin Concentration (g/dL) |
| `HCT` | DECIMAL(10,2) | Hematocrit (%) |
| `MCV` | DECIMAL(10,2) | Mean Corpuscular Volume (fL) |
| `MCH` | DECIMAL(10,2) | Mean Corpuscular Hemoglobin (pg) |
| `MCHC` | DECIMAL(10,2) | MCHC (g/dL) |
| `RDW_CV` | DECIMAL(10,2) | RDW Coefficient of Variation (%) |
| `RDW_SD` | DECIMAL(10,2) | RDW Standard Deviation (fL) |
| `PLT` | DECIMAL(10,0) | Platelets Count (/cumm) |
| `MPV` | DECIMAL(10,2) | Mean Platelet Volume (fL) |
| `PDW` | DECIMAL(10,2) | Platelet Distribution Width |
| `PCT` | DECIMAL(10,4) | Plateletcrit (%) |
| `P_LCR` | DECIMAL(10,2) | Platelet Larger Cell Ratio (%) |
| `P_LCC` | DECIMAL(10,2) | Platelet Large Cell Count (10⁹/L) |
| `NEU_P` | DECIMAL(10,2) | Neutrophils Percentage (%) |
| `LYM_P` | DECIMAL(10,2) | Lymphocytes Percentage (%) |
| `MON_P` | DECIMAL(10,2) | Monocytes Percentage (%) |
| `EOS_P` | DECIMAL(10,2) | Eosinophils Percentage (%) |
| `BAS_P` | DECIMAL(10,2) | Basophils Percentage (%) |
| `LIC_P` | DECIMAL(10,2) | Large Immature Cells Percentage (%) |
| `ALY_P` | DECIMAL(10,2) | Atypical Lymphocytes Percentage (%) |
| `NEU_N` | DECIMAL(10,2) | Neutrophils Absolute Count (10⁹/L) |
| `LYM_N` | DECIMAL(10,2) | Lymphocytes Absolute Count (10⁹/L) |
| `MON_N` | DECIMAL(10,2) | Monocytes Absolute Count (10⁹/L) |
| `EOS_N` | DECIMAL(10,2) | Eosinophils Absolute Count (10⁹/L) |
| `BAS_N` | DECIMAL(10,2) | Basophils Absolute Count (10⁹/L) |
| `LIC_N` | DECIMAL(10,2) | Large Immature Cells Absolute (10⁹/L) |
| `ALY_N` | DECIMAL(10,2) | Atypical Lymphocytes Absolute (10⁹/L) |
| `TCE` | DECIMAL(10,2) | Total Cellular Elements (/cumm) |

---

## 🛠️ Compilation & Development Guide

The solution is written in clean, high-performance C# (compatible with .NET Framework 4.0 through 4.8.1).

### Build Script (`build.bat`):
Run `build.bat` from command line or PowerShell to compile all binaries simultaneously:
```cmd
.\build.bat
```

This compiles:
* `AlienLISMiddleware.exe`: Primary GUI application and communication engine.
* `KT44Receiver.exe`: Backward-compatible secondary launcher.
* `LicenseGenerator.exe`: Visual GUI activation and license management app.
* `KeyGen.exe`: Fast command-line activation generator.

---

## 🔐 Licensing & Commercial Support

* **🎁 7-Day Evaluation Trial**: Click the Free Trial button in the Security tab to test the full suite with 100% features enabled.
* **Permanent Activation**: Send your Hardware Machine ID to Alien Software Development for lifetime offline licensing.

### Contact & Repository Information:
* **Developer**: Alien Software Development
* **WhatsApp / Phone**: [+8801710978997](https://wa.me/8801710978997)
* **Official Website**: [https://aliensoftwaredevelopment.com](https://aliensoftwaredevelopment.com)
* **GitHub Organization**: [https://github.com/alien-software-development](https://github.com/alien-software-development)
* **Email**: [aliensoftwaredevelopment@gmail.com](mailto:aliensoftwaredevelopment@gmail.com)
* **Location**: Dhaka, Bangladesh
