@echo off
echo ==============================================================
echo Creating Desktop Shortcut for Alien LIS Middleware Pro...
echo ==============================================================
set SCRIPT="%TEMP%\%RANDOM%-%RANDOM%_shortcut.vbs"
echo Set oWS = WScript.CreateObject("WScript.Shell") >> %SCRIPT%
echo sLinkFile = oWS.SpecialFolders("Desktop") ^& "\Alien LIS Middleware Pro.lnk" >> %SCRIPT%
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> %SCRIPT%
echo oLink.TargetPath = "%~dp0AlienLISMiddleware.exe" >> %SCRIPT%
echo oLink.WorkingDirectory = "%~dp0" >> %SCRIPT%
echo oLink.Description = "Alien KT-44 Hematology LIS Pro" >> %SCRIPT%
echo oLink.IconLocation = "%~dp0AlienLISMiddleware.exe, 0" >> %SCRIPT%
echo oLink.Save >> %SCRIPT%
cscript /nologo %SCRIPT%
del %SCRIPT%
echo [SUCCESS] Desktop shortcut created successfully!
echo You can now launch Alien LIS Middleware directly from your Desktop.
echo ==============================================================
pause